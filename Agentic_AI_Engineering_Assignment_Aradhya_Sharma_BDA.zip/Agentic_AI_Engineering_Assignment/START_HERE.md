# Agentic AI Engineering – Complete Assignment (1 + 2)

One project, extended from Assignment 1 to Assignment 2 (same agent, as the brief requires).

| Deliverable | Location |
|---|---|
| Assignment briefs | `assignment_briefs/` |
| Working agent (backend) | `student_support_agent/server.py`, `app.py`, `agent/` |
| Chat UI (React, "UniAssist" theme) | `student_support_agent/frontend/src/App.jsx` |
| Sample data + policy handbook | `student_support_agent/data/` |
| README (architecture, privacy/approval rules, how to run) | `student_support_agent/README.md` |
| Assignment 1 evaluation (trace, accuracy, latency, tokens) | `student_support_agent/evaluation/evaluation_report.md` |
| Assignment 2 evaluation (privacy tests, unsafe actions, comparison with A1) | `student_support_agent/evaluation/assignment_2_evaluation_report.md` |
| Sample audit records | `student_support_agent/data/audit_log.json`, `pending_approvals.json` |

## Run
```
cd student_support_agent
pip install -r requirements.txt
cp .env.example .env        # add your API key
python server.py            # backend + served React build on port 8000
```
Frontend rebuild (after UI edits): `npm install --prefix frontend && npm run build --prefix frontend`
