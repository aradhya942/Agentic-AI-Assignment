# PGDM & AI/DS Academic Institute
## Official Student Policy & Handbook (Academic Year 2025-2027)

---

### Section 1: Tuition Fee Payment, Portal Glitches, and Late Fines

#### 1.1 Payment Schedules and Deadlines
- Trimester tuition fees are due on the 10th calendar day of each trimester commencement month (e.g. Term 1: July 10, Term 2: November 10, Term 3: March 10).
- Permitted payment channels: Official Student Portal (NetBanking / UPI / Credit & Debit Cards) and Institute Virtual Account NEFT/RTGS transfers. Cash payments are strictly not accepted.
- Fee installment options: Students facing genuine financial distress may request to split the trimester fee into two equal installments by submitting an application to the Finance Office at least 7 days before the due date.

#### 1.2 Payment Portal Failure and Grace Period Policy
- In the event of a payment gateway failure, server downtime, or banking timeout on or near the payment due date:
  - If a student encounters a technical failure during payment on the due date, they are granted a formal grace period of **two (2) business / working days** to complete the transaction without penalty.
  - To avail this grace period, the student must retain the transaction reference ID, screenshot of the gateway failure message, or immediate support ticket reference.
  - No late penalty fee shall be levied if the payment is completed within this 2-working-day window.

#### 1.3 Late Fee Structure and Account Suspension
- If fee payment is delayed beyond the due date (and beyond the technical grace period):
  - Days 1 to 7 delay: Late fine of INR 500.
  - Days 8 to 15 delay: Late fine of INR 1,500.
  - Beyond 15 days: Formal suspension of campus Wi-Fi, ERP/LMS access, and library issuing privileges until all pending dues and late fines are cleared.

#### 1.4 Fee Refund and Programme Withdrawal
- If a student formally withdraws before the start of the academic term, 90% of tuition fees are refunded after deducting a processing fee of INR 1,000.
- If withdrawal occurs within 15 days of term commencement, 50% tuition is refunded. Beyond 30 days, no fee refund is admissible.

---

### Section 2: Scholarships, Financial Aid, and Retention Rules

#### 2.1 Merit-Based Scholarships
- **Chairman's Merit Award**: 50% tuition waiver for students scoring above the 90th percentile in entrance exams and maintaining a CGPA >= 8.5.
- **Dean's Excellence Scholarship**: 25% tuition waiver for students maintaining a CGPA >= 7.8 with zero academic backlogs.
- **Women in Tech Concession**: 15% tuition concession for female students enrolled in AI & Data Science programmes maintaining a CGPA >= 7.5.

#### 2.2 Retention and Renewal Criteria
- To retain any scholarship or tuition fee concession for subsequent trimesters, the student must satisfy ALL of the following:
  - Maintain a minimum cumulative grade point average (CGPA) of **7.5 out of 10.0**.
  - Maintain a minimum overall classroom attendance of **75%** across all registered courses.
  - Have zero disciplinary warnings or academic integrity violations on their conduct record.
- If a student's CGPA drops below 7.5, the scholarship is placed on probationary hold for one trimester. If not recovered, it is revoked.

---

### Section 3: Course Registration, Elective Changes, and Add/Drop Policy

#### 3.1 Course Change and Elective Selection Window
- Course and elective module changes (Add/Drop) are permitted only during the first **two (2) weeks (14 calendar days)** of the academic trimester.
- Course changes require digital approval from the respective Programme Chairperson and Faculty Advisor.
- Requests submitted after the 14-day window will be rejected without exception.

#### 3.2 Maximum and Minimum Credit Limits
- Full-time PGDM students must enroll for a minimum of 18 credits and a maximum of 26 credits per trimester.
- Over-crediting beyond 26 credits requires an endorsement from the Dean of Academics and a prior trimester CGPA >= 8.0.

---

### Section 4: Attendance, Medical Leave, and Examinations

#### 4.1 Attendance Minimums and Exam Eligibility
- Students must maintain a minimum of **75% attendance** in each individual course to be eligible to sit for the end-trimester final examination.
- Attendance between 65% and 74% due to documented medical emergencies requires submission of a certified medical certificate within 3 working days of resumption, subject to review by the Medical Board.
- Attendance below 65% results in an automatic "F-Grade" (Course Incomplete) requiring mandatory retake in the following academic cycle.

#### 4.2 Medical Leave Procedure
- For any illness lasting more than 2 consecutive days, students must submit a registered medical practitioner's certificate and fitness certificate to the Academic Office within 72 hours of returning to campus.
- Maximum medical leave condonation allowed is 10% of total course contact hours.

---

### Section 5: Examinations, Grading, Backlogs, and Re-evaluation

#### 5.1 Grading Scale and CGPA Calculation
- The Institute follows a 10-point relative grading scale:
  - A+ (10.0), A (9.0), B+ (8.0), B (7.0), C+ (6.0), C (5.0), F (0.0 - Fail).
- Minimum CGPA required for successful award of the PGDM diploma is 5.0 out of 10.0.

#### 5.2 Exam Hall Tickets and Discrepancies
- Hall tickets are issued digitally on the student portal 5 days before term examinations.
- Hall tickets are blocked if fee dues are unpaid or attendance is below 75%. Students must clear financial clearance or obtain a condonation order to unblock hall tickets.

#### 5.3 Grade Re-evaluation and Paper Verification
- Students may apply for end-trimester answer sheet re-checking or re-evaluation within 7 calendar days of grade announcement.
- Re-evaluation fee: INR 750 per subject. If the revised score increases by more than 10%, the fee is refunded.

#### 5.4 Supplementary Exams and Backlogs
- Students obtaining an 'F' grade may register for the Supplementary Examination held before the start of the next academic year.
- A maximum of two backlogs are permitted to carry forward into the second year. Students with more than two active backlogs face a year back.

---

### Section 6: Placements, Internships, and Career Services

#### 6.1 Summer Internship Project (SIP)
- Every PGDM student must undergo a mandatory 8-to-10-week corporate Summer Internship Project at the end of Trimester 3.
- Minimum CGPA to participate in campus internship drives is 6.0 with zero active backlogs.

#### 6.2 Final Campus Placement Rules
- "One Offer Policy": Once a student secures a campus job offer, they are deemed placed and cannot sit for subsequent companies, unless the subsequent offer offers a CTC at least 30% higher ("Dream Offer").
- Minimum 85% attendance in all pre-placement training modules, mock interviews, and resume workshops is mandatory to participate in campus placement drives.

---

### Section 7: Campus Life, Hostel, Wi-Fi, and Library

#### 7.1 Campus Wi-Fi and IT Access
- High-speed campus Wi-Fi credentials are assigned at registration.
- Device limit: Up to 2 registered devices per student.
- Peer-to-peer torrent downloads, unauthorized network scanning, and cryptocurrency mining are strictly prohibited and result in permanent network MAC bans.

#### 7.2 Hostel Rules and Curfew Timings
- Hostel gate curfew timing: 10:30 PM on weekdays (Sunday to Thursday) and 11:30 PM on weekends (Friday and Saturday).
- Night-out leaves require prior digital parent approval on the hostel ERP module submitted at least 24 hours in advance.

#### 7.3 Library Borrowing and Fines
- Students may borrow up to 4 textbooks simultaneously for a borrowing period of 14 calendar days.
- Overdue library fine: INR 10 per day per book.
- Digital library databases (IEEE, Scopus, HBR Cases) are accessible on-campus and remotely via institutional VPN credentials.

---

### Section 8: Transcripts, Certificates, and Support Desk

#### 8.1 Official Transcripts and Bonafide Certificates
- Bonafide student certificates, fee estimates for education loans, and interim grade transcripts can be requested through the Student Support Agent or ERP helpdesk.
- Standard processing time: 2 working days for digital certificates, 5 working days for physical hard-copy sealed transcripts.

#### 8.2 Submitting Helpdesk Support Tickets
- Standard resolution SLAs:
  - Urgent (payment failure block, hall ticket error on exam day): within 24 hours.
  - Medium (grade re-check, elective change approval): within 48 hours.
  - General (bonafide certificate, Wi-Fi MAC registration): within 3-4 working days.
