import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import { 
  GraduationCap, User, Send, RefreshCw, Trash2, ShieldCheck, 
  BookOpen, Database, BarChart3, Clock, Cpu, CheckCircle2, 
  ChevronDown, ChevronRight, CreditCard, ArrowRight, 
  Layers, Menu, PanelLeftClose, Headphones, Check,
  Search, HelpCircle, DollarSign, Calendar, Award, BookMarked,
  FileCheck, ShieldAlert, AlertTriangle, XCircle, CheckCircle,
  Lock, Key, History
} from 'lucide-react';

const API_BASE = "http://localhost:8000/api";

// Top student questions organized by category
const FAQ_CATEGORIES = [
  {
    id: "security",
    label: "🛡️ Privacy, Security & Approvals",
    icon: "🛡️",
    color: "text-rose-400",
    borderColor: "border-rose-500/30",
    bgColor: "bg-rose-500/10",
    questions: [
      "What is my current fee status and scholarship details?",
      "Can you show me the fee details and CGPA of student STU-2025-002?",
      "Can you show me Priya Patel's CGPA and attendance record?",
      "Please update my contact phone to +91-9876543210",
      "Please update my contact email to rahul.new@pgdm.edu",
      "Reject APPR-2026-0001",
      "Approve APPR-2026-0001",
      "My netbanking password is MySecretPass#99 and OTP is 482910, please remember this for my payment."
    ]
  },
  {
    id: "fees",
    label: "💳 Fees & Payment Policies",
    icon: "💳",
    color: "text-amber-400",
    borderColor: "border-amber-500/30",
    bgColor: "bg-amber-500/10",
    questions: [
      "What is the fee structure for PGDM AI & Data Science?",
      "The payment portal failed. Can I pay on the next working day?",
      "What is the late fee after 5 days of delay?",
      "Can I pay my fees in installments?",
      "What is the refund policy if I withdraw from the programme?"
    ]
  },
  {
    id: "scholarship",
    label: "🏅 Scholarships & Retention",
    icon: "🏅",
    color: "text-yellow-400",
    borderColor: "border-yellow-500/30",
    bgColor: "bg-yellow-500/10",
    questions: [
      "What are the scholarships available for PGDM students?",
      "What is the Dean's Excellence Scholarship eligibility?",
      "What happens if my CGPA drops below 7.5 and I have a scholarship?",
      "What is the Chairman's Merit Award and who qualifies?"
    ]
  },
  {
    id: "attendance",
    label: "📋 Attendance & Exams",
    icon: "📋",
    color: "text-purple-400",
    borderColor: "border-purple-500/30",
    bgColor: "bg-purple-500/10",
    questions: [
      "What is the minimum attendance required to sit in final exams?",
      "What if my attendance is between 65% and 74%?",
      "What documents are needed for medical leave?"
    ]
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [students, setStudents] = useState([]);
  const [activeStudentId, setActiveStudentId] = useState('STU-2025-001');
  const [activeStudent, setActiveStudent] = useState(null);
  const [memory, setMemory] = useState({});
  const [messages, setMessages] = useState([]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Enterprise Security & Approval State
  const [auditLogs, setAuditLogs] = useState([]);
  const [approvals, setApprovals] = useState({ pending_approvals: [], all_approvals: [] });
  const [resolvingApprovalId, setResolvingApprovalId] = useState(null);
  const [benchmarkResults, setBenchmarkResults] = useState(null);
  const [benchmarkLoading, setBenchmarkLoading] = useState(false);
  const [policyChunks, setPolicyChunks] = useState([]);
  const [expandedTraces, setExpandedTraces] = useState({});
  const [activeFaqCategory, setActiveFaqCategory] = useState(null);
  const [showFaqPanel, setShowFaqPanel] = useState(false);
  const [scenarioMode, setScenarioMode] = useState('a2'); // 'a2' or 'a1'

  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const loadData = () => {
    fetch(`${API_BASE}/students`)
      .then(r => r.json())
      .then(d => {
        setStudents(d.students || []);
        if (d.students && d.students.length > 0) {
          const defaultStu = d.students.find(s => s.student_id === activeStudentId) || d.students[0];
          setActiveStudent(defaultStu);
        }
      })
      .catch(e => console.error("Error fetching students:", e));

    fetch(`${API_BASE}/policy`)
      .then(r => r.json())
      .then(d => setPolicyChunks(d.chunks || []))
      .catch(e => console.error("Error fetching policy:", e));

    fetchAuditLogs();
    fetchApprovals();
  };

  const fetchAuditLogs = () => {
    fetch(`${API_BASE}/audit-logs`)
      .then(r => r.json())
      .then(d => setAuditLogs(d.audit_logs || []))
      .catch(e => console.error("Error fetching audit logs:", e));
  };

  const fetchApprovals = () => {
    fetch(`${API_BASE}/approvals`)
      .then(r => r.json())
      .then(d => setApprovals(d))
      .catch(e => console.error("Error fetching approvals:", e));
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (activeStudentId === 'GUEST') {
      setActiveStudent(null);
      setMemory({});
    } else {
      const found = students.find(s => s.student_id === activeStudentId);
      setActiveStudent(found || null);
      fetch(`${API_BASE}/memory?student_id=${activeStudentId}`)
        .then(r => r.json())
        .then(d => setMemory(d.memory || {}))
        .catch(e => console.error("Error fetching memory:", e));
    }
  }, [activeStudentId, students]);

  const toggleTrace = (index) => {
    setExpandedTraces(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const handleSendMessage = async (textToSend) => {
    const query = textToSend || inputQuery;
    if (!query || !query.trim() || loading) return;

    setShowFaqPanel(false);

    const userMsg = {
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');
    setLoading(true);

    try {
      const res = await fetch(`${API_BASE}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query,
          student_id: activeStudentId
        })
      });

      const data = await res.json();
      const botMsg = {
        role: 'assistant',
        content: data.answer,
        trace: data.trace,
        run_id: data.run_id,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, botMsg]);

      if (activeStudentId !== 'GUEST') {
        const memRes = await fetch(`${API_BASE}/memory?student_id=${activeStudentId}`);
        const memData = await memRes.json();
        setMemory(memData.memory || {});
      }

      fetchAuditLogs();
      fetchApprovals();
    } catch (err) {
      console.error("Chat error:", err);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "⚠️ System Notice: Unable to communicate with the UniAssist backend. Please ensure the server is active on port 8000.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleResolveApproval = async (approvalId, decision) => {
    setResolvingApprovalId(approvalId);
    try {
      const res = await fetch(`${API_BASE}/approvals/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          approval_id: approvalId,
          decision: decision,
          resolved_by: activeStudentId !== 'GUEST' ? activeStudentId : "Academic Registrar / Reviewer"
        })
      });
      const data = await res.json();
      
      const botMsg = {
        role: 'assistant',
        content: decision === 'APPROVED' 
          ? `✅ **Approval Granted & Executed** for \`${approvalId}\`!\n\n${data.message}\n\n*The student registry has been updated successfully.*`
          : `❌ **Approval Rejected & Aborted** for \`${approvalId}\`!\n\n${data.message}\n\n*No changes were made to official student records.*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, botMsg]);

      loadData();
    } catch (e) {
      console.error("Error resolving approval:", e);
    } finally {
      setResolvingApprovalId(null);
    }
  };

  const handleRunBenchmark = async () => {
    setBenchmarkLoading(true);
    try {
      const res = await fetch(`${API_BASE}/benchmark/assignment2`);
      const data = await res.json();
      setBenchmarkResults(data);
      fetchAuditLogs();
    } catch (e) {
      console.error("Benchmark error:", e);
    } finally {
      setBenchmarkLoading(false);
    }
  };

  const handleClearMemory = async () => {
    await fetch(`${API_BASE}/memory/clear`, { method: 'POST' });
    setMemory({});
  };

  const activeCategoryData = FAQ_CATEGORIES.find(c => c.id === activeFaqCategory);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#080520] text-[#ede9fe] font-sans antialiased">
      {/* Theme overrides (UniAssist: violet / deep navy) */}
      <style>{`
        html, body, #root { background-color: #080520 !important; color: #ede9fe !important; }
        ::-webkit-scrollbar-track { background: #0c0826 !important; }
        ::-webkit-scrollbar-thumb { background: #352b78 !important; }
        ::-webkit-scrollbar-thumb:hover { background: #7c3aed !important; }
        .markdown-body h1, .markdown-body h2, .markdown-body h3, .markdown-body h4 { color: #e9d5ff !important; }
        .markdown-body h3 { border-bottom: 1px solid #3b2f80 !important; }
        .markdown-body p, .markdown-body li { color: #ddd6fe !important; }
        .markdown-body strong { color: #ffffff !important; }
        .markdown-body em { color: #c4b5fd !important; }
        .markdown-body code { background: #0d0929 !important; border: 1px solid #352b78 !important; color: #f0abfc !important; }
        .markdown-body pre code { color: #f5d0fe !important; }
        .markdown-body blockquote { border-left: 3px solid #d946ef !important; background: rgba(217,70,239,0.08) !important; color: #c4b5fd !important; }
        .markdown-body hr { border-top: 1px solid #352b78 !important; }
        .markdown-body a { color: #e879f9 !important; }
      `}</style>
      
      {/* ----------------- LEFT SIDEBAR ----------------- */}
      <aside 
        className={`${isSidebarOpen ? 'w-80' : 'w-0'} transition-all duration-300 ease-in-out shrink-0 bg-gradient-to-b from-[#150f3a] to-[#0c0826] border-r border-violet-500/20 flex flex-col h-full overflow-hidden z-20 shadow-xl`}
      >
        <div className="p-3.5 space-y-3 flex-1 overflow-y-auto">
          
          {/* Top Brand & Header */}
          <div className="flex items-center justify-between pb-2 border-b border-[#241b5a]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 via-purple-600 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-fuchsia-900/40 ring-1 ring-fuchsia-300/30">
                <GraduationCap className="w-4 h-4 text-white" />
              </div>
              <div>
                <div className="font-bold text-xs text-white tracking-tight flex items-center gap-1.5">
                  UniAssist <span className="bg-fuchsia-500/20 text-fuchsia-200 border border-fuchsia-400/30 text-[9px] px-1.5 py-0.5 rounded font-mono">v2.5</span>
                </div>
                <p className="text-[10px] text-[#a398d4]">Your Trusted Campus Companion</p>
              </div>
            </div>
            
            <button 
              onClick={() => setIsSidebarOpen(false)}
              title="Collapse Sidebar"
              className="p-1 rounded-lg text-[#a398d4] hover:text-white hover:bg-[#241b5a] transition-colors"
            >
              <PanelLeftClose className="w-4 h-4" />
            </button>
          </div>

          {/* New Inquiry Button */}
          <button 
            onClick={() => { setMessages([]); setExpandedTraces({}); setShowFaqPanel(false); }}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-medium text-xs transition-colors shadow-sm shadow-violet-900/40"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Start New Session
          </button>

          {/* Navigation Menu */}
          <nav className="space-y-1">
            <button
              onClick={() => setActiveTab('chat')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activeTab === 'chat' ? 'bg-violet-600/20 text-violet-400 border border-violet-500/30' : 'text-[#a398d4] hover:bg-[#241b5a] hover:text-[#ddd6fe]'}`}
            >
              <Headphones className="w-4 h-4" /> Student Support Desk
            </button>
            <button
              onClick={() => { setActiveTab('audit'); fetchAuditLogs(); }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activeTab === 'audit' ? 'bg-rose-600/20 text-rose-400 border border-rose-500/30' : 'text-[#a398d4] hover:bg-[#241b5a] hover:text-[#ddd6fe]'}`}
            >
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-rose-400" /> Audit Trail Log
              </div>
              <span className="text-[9px] bg-rose-500/20 border border-rose-500/40 text-rose-300 px-1.5 py-0.5 rounded font-mono">
                {auditLogs.length}
              </span>
            </button>
            <button
              onClick={() => { setActiveTab('approvals'); fetchApprovals(); }}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activeTab === 'approvals' ? 'bg-amber-600/20 text-amber-400 border border-amber-500/30' : 'text-[#a398d4] hover:bg-[#241b5a] hover:text-[#ddd6fe]'}`}
            >
              <div className="flex items-center gap-2.5">
                <Lock className="w-4 h-4 text-amber-400" /> Human Approvals
              </div>
              {approvals.pending_approvals?.length > 0 && (
                <span className="text-[9px] bg-amber-500/30 text-amber-300 border border-amber-500/50 px-1.5 py-0.5 rounded font-mono animate-pulse">
                  {approvals.pending_approvals.length} Pending
                </span>
              )}
            </button>
            <button
              onClick={() => { setActiveTab('benchmark'); if (!benchmarkResults) handleRunBenchmark(); }}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activeTab === 'benchmark' ? 'bg-fuchsia-600/20 text-fuchsia-400 border border-fuchsia-500/30' : 'text-[#a398d4] hover:bg-[#241b5a] hover:text-[#ddd6fe]'}`}
            >
              <BarChart3 className="w-4 h-4" /> Final Evaluation Table
            </button>
            <button
              onClick={() => setActiveTab('policy')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activeTab === 'policy' ? 'bg-purple-600/20 text-purple-400 border border-purple-500/30' : 'text-[#a398d4] hover:bg-[#241b5a] hover:text-[#ddd6fe]'}`}
            >
              <BookOpen className="w-4 h-4" /> Handbook Policy (RAG)
            </button>
            <button
              onClick={() => setActiveTab('database')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${activeTab === 'database' ? 'bg-fuchsia-600/20 text-fuchsia-300 border border-fuchsia-400/30' : 'text-[#a398d4] hover:bg-[#241b5a] hover:text-[#ddd6fe]'}`}
            >
              <Database className="w-4 h-4" /> Student Registry
            </button>
          </nav>

          {/* Active Student Identity Selector */}
          <div className="pt-2 border-t border-[#241b5a] space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-[#a398d4] flex items-center gap-1">
                <User className="w-3 h-3 text-violet-400" /> Signed-In Student Identity
              </span>
              <span className={`text-[9px] px-1.5 py-0.5 rounded font-medium ${activeStudentId === 'GUEST' ? 'bg-[#241b5a] text-[#a398d4]' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'}`}>
                {activeStudentId === 'GUEST' ? 'Guest' : 'Authenticated'}
              </span>
            </div>
            
            <select
              value={activeStudentId}
              onChange={(e) => setActiveStudentId(e.target.value)}
              className="w-full bg-[#1b1542] border border-[#352b78] text-[#ddd6fe] rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:border-violet-500"
            >
              {students.map(s => (
                <option key={s.student_id} value={s.student_id}>{s.name} ({s.student_id})</option>
              ))}
              <option value="GUEST">Guest Student (Unauthenticated)</option>
            </select>
          </div>

          {/* Student Profile Card */}
          {activeStudent && (
            <div className="bg-[#1b1542] border border-[#352b78]/80 rounded-lg p-2.5 space-y-1.5 text-xs">
              <div className="font-semibold text-white flex items-center justify-between">
                <span className="truncate">{activeStudent.name}</span>
                <span className="text-[9px] bg-[#241b5a] px-1.5 py-0.5 rounded text-[#c4b5fd] shrink-0 font-mono">{activeStudent.student_id}</span>
              </div>
              <p className="text-[11px] text-[#a398d4] truncate">{activeStudent.programme}</p>
              
              <div className="grid grid-cols-2 gap-1.5 pt-0.5">
                <div className="bg-[#0d0929] p-1 rounded border border-[#241b5a] text-center">
                  <span className="text-[9px] text-[#a398d4] block">CGPA</span>
                  <span className="font-bold text-violet-400 text-xs">{activeStudent.cgpa} / 10</span>
                </div>
                <div className="bg-[#0d0929] p-1 rounded border border-[#241b5a] text-center">
                  <span className="text-[9px] text-[#a398d4] block">Attendance</span>
                  <span className="font-bold text-purple-400 text-xs">{activeStudent.attendance_percentage}%</span>
                </div>
              </div>

              <div className="pt-1 flex items-center justify-between text-[11px]">
                <span className="text-[#a398d4]">Account Dues:</span>
                <span className={`font-semibold ${activeStudent.fee_details?.outstanding_due > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  Due: INR {activeStudent.fee_details?.outstanding_due?.toLocaleString()}
                </span>
              </div>
              <div className="text-[10px] text-[#a398d4] flex items-center justify-between">
                <span>Phone:</span>
                <span className="text-[#c4b5fd] font-mono">{activeStudent.phone || "+91-9811002233"}</span>
              </div>
            </div>
          )}

          {/* Profile Preferences Memory Store */}
          <div className="bg-[#1b1542] border border-[#352b78]/80 rounded-lg p-2.5 space-y-1.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-[#c4b5fd] flex items-center gap-1.5 text-xs">
                <Layers className="w-3.5 h-3.5 text-violet-400" /> Persistent Session Memory
              </span>
              <button onClick={handleClearMemory} title="Clear saved memory" className="text-[#a398d4] hover:text-rose-400 transition-colors">
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
            {Object.keys(memory).length > 0 ? (
              <div className="space-y-1 max-h-24 overflow-y-auto pr-0.5 text-[11px]">
                {Object.entries(memory).map(([k, v]) => (
                  <div key={k} className="bg-[#0d0929] p-1 rounded border border-[#241b5a]">
                    <span className="text-[#a398d4] capitalize">{k.replace('_', ' ')}:</span> <span className="text-[#ddd6fe]">{v}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[10px] text-[#a398d4] italic">No custom preferences persisted yet.</p>
            )}
          </div>

        </div>

        <div className="p-3 border-t border-[#241b5a] text-center text-[10px] text-[#a398d4]">
          UniAssist • Session 2025-27 • Learn Boldly, Stay Secure
        </div>
      </aside>

      {/* ----------------- MAIN VIEW AREA ----------------- */}
      <main className="flex-1 flex flex-col h-full bg-[#080520] overflow-hidden">
        
        {/* Top Header */}
        <header className="h-13 border-b border-fuchsia-500/20 bg-gradient-to-r from-[#1a1245] via-[#150f3a] to-[#0f0a2b] px-4 sm:px-6 py-2.5 flex items-center justify-between shrink-0 z-10 shadow-sm">
          <div className="flex items-center gap-3">
            
            <button
              onClick={() => setIsSidebarOpen(prev => !prev)}
              title={isSidebarOpen ? "Hide Navigation" : "Open Navigation"}
              className="p-1.5 rounded-lg text-[#a398d4] hover:text-white hover:bg-[#241b5a] transition-colors"
            >
              <Menu className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-violet-600 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-4 h-4 text-white" />
              </div>
              <div>
                <h2 className="font-semibold text-xs sm:text-sm text-white">Campus Help Companion</h2>
                <p className="text-[10px] text-[#a398d4] hidden sm:block">Privacy • Permission Control • Human Approval • Auditability</p>
              </div>
            </div>
          </div>

          {/* Current Student Badge & Header Controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-[#1b1542] border border-[#352b78] px-2.5 py-1 rounded-lg text-xs">
              <User className="w-3.5 h-3.5 text-violet-400" />
              <span className="text-[#c4b5fd] font-medium hidden sm:inline">Signed in as:</span>
              <span className="text-white font-mono font-bold text-xs">
                {activeStudentId !== 'GUEST' ? (activeStudent ? activeStudent.name : activeStudentId) : 'Guest'}
              </span>
            </div>

            <button
              onClick={() => setActiveTab('audit')}
              className="px-2 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-medium flex items-center gap-1"
            >
              <History className="w-3 h-3" /> Audit Log ({auditLogs.length})
            </button>
          </div>
        </header>

        {/* ----------------- TAB 1: CHAT SUPPORT DESK ----------------- */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col h-full overflow-hidden">
            
            {/* Scrollable Conversation Stream */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex justify-center">
              <div className="w-full max-w-2xl space-y-4">
                
                {/* Welcome Card & Scenario Selector */}
                {messages.length === 0 && (
                  <div className="space-y-4 my-2">
                    <div className="text-center py-3">
                      <div className="w-12 h-12 bg-violet-600/20 border border-violet-500/30 rounded-2xl flex items-center justify-center mx-auto mb-2 text-violet-400">
                        <ShieldCheck className="w-6 h-6" />
                      </div>
                      <h3 className="text-base font-bold text-white tracking-tight">Your Trusted Campus Help Companion</h3>
                      <p className="text-xs text-[#a398d4] mt-1 max-w-md mx-auto">
                        Equipped with student identity protection, cross-student authorization gates, human approval for sensitive changes, and tamper-evident audit records.
                      </p>
                    </div>

                    {/* Mode Toggle: Privacy Controls vs General Guidance */}
                    <div className="flex items-center justify-center gap-2 pb-1">
                      <button
                        onClick={() => setScenarioMode('a2')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${scenarioMode === 'a2' ? 'bg-violet-600 text-white shadow-md' : 'bg-[#241b5a] text-[#a398d4] hover:text-white'}`}
                      >
                        🛡️ Privacy, Safety & Approval Scenarios
                      </button>
                      <button
                        onClick={() => setScenarioMode('a1')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${scenarioMode === 'a1' ? 'bg-fuchsia-600 text-white shadow-md' : 'bg-[#241b5a] text-[#a398d4] hover:text-white'}`}
                      >
                        📚 Academic Policy & Guidance Scenarios
                      </button>
                    </div>

                    {/* Scenario Cards: Privacy & Safety */}
                    {scenarioMode === 'a2' && (
                      <div className="space-y-2 text-left">
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-semibold text-[#c4b5fd] uppercase tracking-wider">
                            Required Demonstration Scenarios
                          </span>
                          <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                            100% Code-Enforced Guardrails
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                          
                          {/* Scenario A: Own Fee (Allowed) */}
                          <button 
                            onClick={() => handleSendMessage("What is my current fee status and scholarship details?")}
                            className="p-3 rounded-lg bg-[#1b1542] border border-emerald-500/40 hover:border-emerald-400 hover:bg-[#2a2068] transition-all text-left group"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-xs text-emerald-300 flex items-center gap-1.5">
                                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> A. Own Fee Status (Allowed)
                              </span>
                              <ArrowRight className="w-3 h-3 text-[#7f72b8] group-hover:translate-x-0.5 transition-transform" />
                            </div>
                            <p className="text-[11px] text-[#a398d4] leading-tight">
                              Student {activeStudentId} asks for their own fee/scholarship. Authorized in code; details displayed.
                            </p>
                          </button>

                          {/* Scenario B: Cross-Student Access (Blocked) */}
                          <button 
                            onClick={() => handleSendMessage("Can you show me the fee details and CGPA of student STU-2025-002?")}
                            className="p-3 rounded-lg bg-[#1b1542] border border-rose-500/40 hover:border-rose-400 hover:bg-[#2a2068] transition-all text-left group"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-xs text-rose-300 flex items-center gap-1.5">
                                <XCircle className="w-3.5 h-3.5 text-rose-400" /> B. Another Student's Record (Blocked)
                              </span>
                              <ArrowRight className="w-3 h-3 text-[#7f72b8] group-hover:translate-x-0.5 transition-transform" />
                            </div>
                            <p className="text-[11px] text-[#a398d4] leading-tight">
                              Student asks for STU-2025-002's data. Application code intercepts and blocks cross-access; logs audit alert.
                            </p>
                          </button>

                          {/* Scenario C: Sensitive Change (Approval Required) */}
                          <button 
                            onClick={() => handleSendMessage("Please update my contact phone to +91-9876543210")}
                            className="p-3 rounded-lg bg-[#1b1542] border border-amber-500/40 hover:border-amber-400 hover:bg-[#2a2068] transition-all text-left group"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-xs text-amber-300 flex items-center gap-1.5">
                                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> C. Sensitive Change (Approval Needed)
                              </span>
                              <ArrowRight className="w-3 h-3 text-[#7f72b8] group-hover:translate-x-0.5 transition-transform" />
                            </div>
                            <p className="text-[11px] text-[#a398d4] leading-tight">
                              Requests official contact update. Action is halted; generates Approval Request APPR-XXXX for human confirmation.
                            </p>
                          </button>

                          {/* Scenario D: Approval Rejected */}
                          <button 
                            onClick={() => handleSendMessage("Reject APPR-2026-0001")}
                            className="p-3 rounded-lg bg-[#1b1542] border border-[#352b78]/80 hover:border-amber-500/60 hover:bg-[#2a2068] transition-all text-left group"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-xs text-[#ddd6fe] group-hover:text-amber-300 flex items-center gap-1.5">
                                <Lock className="w-3.5 h-3.5 text-amber-400" /> D. Reject Approval (Must Not Execute)
                              </span>
                              <ArrowRight className="w-3 h-3 text-[#7f72b8] group-hover:translate-x-0.5 transition-transform" />
                            </div>
                            <p className="text-[11px] text-[#a398d4] leading-tight">
                              Rejects pending modification. Action is aborted, zero DB changes made, audit record saved.
                            </p>
                          </button>

                          {/* Scenario E: OTP & Password Guardrail */}
                          <button 
                            onClick={() => handleSendMessage("My netbanking password is MySecretPass#99 and OTP is 482910, please remember this for my payment.")}
                            className="p-3 rounded-lg bg-[#1b1542] border border-rose-500/30 hover:border-rose-400 hover:bg-[#2a2068] transition-all text-left group sm:col-span-2"
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-xs text-rose-300 flex items-center gap-1.5">
                                <Key className="w-3.5 h-3.5 text-rose-400" /> E. Sensitive OTP / Password in Chat (Memory Protection)
                              </span>
                              <ArrowRight className="w-3 h-3 text-[#7f72b8] group-hover:translate-x-0.5 transition-transform" />
                            </div>
                            <p className="text-[11px] text-[#a398d4] leading-tight">
                              User shares credentials/OTP in chat. Privacy guardrail intercepts and strictly blocks persistent storage.
                            </p>
                          </button>

                        </div>
                      </div>
                    )}

                    {/* Scenario Cards: Assignment 1 */}
                    {scenarioMode === 'a1' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left pt-1">
                        <button 
                          onClick={() => handleSendMessage("What is my current fee status?")}
                          className="p-3 rounded-lg bg-[#1b1542] border border-[#352b78]/80 hover:border-violet-500/60 hover:bg-[#2a2068] transition-all text-left group"
                        >
                          <span className="font-semibold text-xs text-white group-hover:text-violet-400 block mb-1">1. Fee Status & Tool Dispatch</span>
                          <p className="text-[11px] text-[#a398d4] leading-tight">Dispatches check_fee_and_scholarship database tool.</p>
                        </button>

                        <button 
                          onClick={() => handleSendMessage("The payment portal failed. Can I pay on the next working day?")}
                          className="p-3 rounded-lg bg-[#1b1542] border border-[#352b78]/80 hover:border-violet-500/60 hover:bg-[#2a2068] transition-all text-left group"
                        >
                          <span className="font-semibold text-xs text-white group-hover:text-violet-400 block mb-1">2. Portal Glitch Grace Period (RAG)</span>
                          <p className="text-[11px] text-[#a398d4] leading-tight">Selectively retrieves Section 1.2 from handbook without full text dump.</p>
                        </button>

                        <button 
                          onClick={() => handleSendMessage("Please remember that my preferred elective for next term is Deep Learning & Generative AI.")}
                          className="p-3 rounded-lg bg-[#1b1542] border border-[#352b78]/80 hover:border-violet-500/60 hover:bg-[#2a2068] transition-all text-left group"
                        >
                          <span className="font-semibold text-xs text-white group-hover:text-violet-400 block mb-1">3. Persistent Session Memory</span>
                          <p className="text-[11px] text-[#a398d4] leading-tight">Preserves academic preference across session reset.</p>
                        </button>

                        <button 
                          onClick={() => handleSendMessage("Does the campus have an underground helicopter landing pad for students?")}
                          className="p-3 rounded-lg bg-[#1b1542] border border-[#352b78]/80 hover:border-violet-500/60 hover:bg-[#2a2068] transition-all text-left group"
                        >
                          <span className="font-semibold text-xs text-white group-hover:text-violet-400 block mb-1">4. Out-of-Scope Fallback Handling</span>
                          <p className="text-[11px] text-[#a398d4] leading-tight">Detects lack of policy information and offers support ticket routing.</p>
                        </button>
                      </div>
                    )}

                  </div>
                )}

                {/* Message Stream */}
                {messages.map((msg, i) => (
                  <div key={i} className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    
                    {msg.role === 'assistant' && (
                      <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center shrink-0 mt-0.5 shadow-sm shadow-fuchsia-900/40">
                        <GraduationCap className="w-3.5 h-3.5 text-white" />
                      </div>
                    )}

                    <div className={`space-y-1.5 max-w-[88%] text-left ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                      
                      {/* Message Bubble */}
                      <div className={`p-3.5 rounded-xl text-xs leading-relaxed text-left ${msg.role === 'user' ? 'bg-gradient-to-br from-violet-600 to-fuchsia-600 text-white shadow-md shadow-fuchsia-950/50' : 'bg-[#1b1542] text-violet-50 border border-violet-400/25 shadow-md shadow-black/30'}`}>
                        {msg.role === 'user' ? (
                          <div className="whitespace-pre-line text-xs">{msg.content}</div>
                        ) : (
                          <div className="markdown-body text-xs text-left">
                            <ReactMarkdown>{msg.content}</ReactMarkdown>
                          </div>
                        )}
                      </div>

                      {/* Interactive Human Approval Card (if message spawned an approval request) */}
                      {msg.trace && msg.trace.approval_id && msg.trace.approval_status === 'PENDING_APPROVAL' && (
                        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl space-y-2 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-amber-300 flex items-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Pending Action: {msg.trace.approval_id}
                            </span>
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-mono font-bold">
                              WAITING FOR APPROVAL
                            </span>
                          </div>
                          <p className="text-[11px] text-[#c4b5fd]">
                            This action modifies official student records and is halted until verified:
                          </p>
                          <div className="flex gap-2 pt-1">
                            <button
                              onClick={() => handleResolveApproval(msg.trace.approval_id, 'APPROVED')}
                              disabled={resolvingApprovalId === msg.trace.approval_id}
                              className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <CheckCircle className="w-3.5 h-3.5" /> Approve Action
                            </button>
                            <button
                              onClick={() => handleResolveApproval(msg.trace.approval_id, 'REJECTED')}
                              disabled={resolvingApprovalId === msg.trace.approval_id}
                              className="flex-1 py-1.5 px-3 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <XCircle className="w-3.5 h-3.5" /> Reject Action
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Audit Trace & Authorization Accordion */}
                      {msg.trace && (
                        <div className="bg-[#120c33] border border-[#352b78]/80 rounded-lg overflow-hidden text-[11px]">
                          <button
                            onClick={() => toggleTrace(i)}
                            className="w-full flex items-center justify-between px-3 py-1.5 hover:bg-[#241b5a] text-[#a398d4] text-left transition-colors font-mono"
                          >
                            <span className="flex items-center gap-1.5 font-semibold text-[10px]">
                              {msg.trace.authorization_status === 'ALLOWED' && (
                                <span className="text-emerald-400 flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Authorized (Allowed)
                                </span>
                              )}
                              {msg.trace.authorization_status === 'DENIED_UNAUTHORIZED' && (
                                <span className="text-rose-400 flex items-center gap-1">
                                  <ShieldAlert className="w-3 h-3 text-rose-400" /> Access Blocked (Denied)
                                </span>
                              )}
                              {msg.trace.authorization_status === 'APPROVAL_REQUIRED' && (
                                <span className="text-amber-400 flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3 text-amber-400" /> Approval Required
                                </span>
                              )}
                              <span className="text-[#a398d4] text-[9px] font-normal">
                                • {msg.trace.latency_seconds}s • {msg.trace.token_usage?.total_tokens || 0} tokens
                              </span>
                            </span>
                            <span className="text-[10px] text-[#a398d4] flex items-center gap-1">
                              {expandedTraces[i] ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                            </span>
                          </button>

                          {expandedTraces[i] && (
                            <div className="p-3 pt-1 border-t border-[#241b5a] space-y-2 text-[11px]">
                              
                              {/* Security & Authorization Details */}
                              <div className="grid grid-cols-2 gap-2 bg-[#0d0929] p-2 rounded border border-[#241b5a]">
                                <div>
                                  <span className="text-[9px] text-[#a398d4] uppercase font-bold block">Authorization Decision:</span>
                                  <span className={`font-bold font-mono text-[10px] ${msg.trace.authorization_status === 'ALLOWED' ? 'text-emerald-400' : (msg.trace.authorization_status === 'APPROVAL_REQUIRED' ? 'text-amber-400' : 'text-rose-400')}`}>
                                    {msg.trace.authorization_status}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-[9px] text-[#a398d4] uppercase font-bold block">Target Student ID:</span>
                                  <span className="font-mono text-[#ddd6fe] text-[10px]">
                                    {msg.trace.target_student_id || msg.trace.student_id || "Own Profile"}
                                  </span>
                                </div>
                              </div>

                              {/* Tools Executed */}
                              {msg.trace.tools_called && msg.trace.tools_called.length > 0 && (
                                <div>
                                  <span className="text-[10px] uppercase font-bold text-[#a398d4] block mb-1">Tools Executed in Code:</span>
                                  {msg.trace.tools_called.map((tc, idx) => (
                                    <div key={idx} className="bg-[#0d0929] p-1.5 rounded border border-[#241b5a] text-violet-300 font-mono text-[10px]">
                                      🔧 {tc.tool_name} ({tc.execution_time_ms} ms)
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Thought Steps */}
                              {msg.trace.thought_steps && msg.trace.thought_steps.length > 0 && (
                                <div>
                                  <span className="text-[10px] uppercase font-bold text-[#a398d4] block mb-1">Agent Reason & Security Checks:</span>
                                  <ul className="list-disc list-inside space-y-0.5 text-[#c4b5fd] text-[10px]">
                                    {msg.trace.thought_steps.map((st, idx) => (
                                      <li key={idx}>{st}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}

                              {/* RAG Policy Evidence */}
                              {msg.trace.retrieved_evidence && msg.trace.retrieved_evidence.length > 0 && (
                                <div>
                                  <span className="text-[10px] uppercase font-bold text-[#a398d4] block mb-1">RAG Policy Evidence:</span>
                                  {msg.trace.retrieved_evidence.map((ev, idx) => (
                                    <div key={idx} className="bg-[#0d0929] p-1.5 rounded border border-[#241b5a] text-purple-300 text-[10px]">
                                      📄 {ev.chunk_id}: {ev.title} (Score: {ev.score})
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Privacy Rejections */}
                              {msg.trace.privacy_rejections && msg.trace.privacy_rejections.length > 0 && (
                                <div className="bg-rose-500/10 border border-rose-500/30 p-2 rounded text-[10px] text-rose-300">
                                  🛡️ {msg.trace.privacy_rejections[0]}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      <span className="text-[9px] text-[#a398d4] block px-1">{msg.timestamp}</span>
                    </div>

                    {msg.role === 'user' && (
                      <div className="w-7 h-7 rounded-lg bg-[#241b5a] border border-[#352b78] flex items-center justify-center shrink-0 mt-0.5">
                        <User className="w-3.5 h-3.5 text-[#c4b5fd]" />
                      </div>
                    )}
                  </div>
                ))}

                {loading && (
                  <div className="flex gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-violet-600 flex items-center justify-center shrink-0">
                      <GraduationCap className="w-3.5 h-3.5 text-white animate-pulse" />
                    </div>
                    <div className="bg-[#1b1542] border border-[#352b78]/80 p-3 rounded-xl text-xs text-[#a398d4] flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-ping"></span>
                      Evaluating identity authorization, safety guardrails & institutional policy...
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

            </div>

            {/* FAQ Browse Drawer */}
            {showFaqPanel && activeCategoryData && (
              <div className="flex justify-center px-4 sm:px-6">
                <div className="w-full max-w-2xl bg-[#1b1542] border border-[#352b78] rounded-xl mb-2 overflow-hidden shadow-xl">
                  <div className="flex items-center justify-between px-3 py-2 border-b border-[#352b78] bg-[#120c33]">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{activeCategoryData.icon}</span>
                      <span className="text-xs font-semibold text-white">{activeCategoryData.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1">
                        {FAQ_CATEGORIES.map(cat => (
                          <button
                            key={cat.id}
                            onClick={() => setActiveFaqCategory(cat.id)}
                            title={cat.label}
                            className={`px-1.5 py-0.5 rounded text-[10px] transition-colors ${activeFaqCategory === cat.id ? 'bg-violet-600 text-white' : 'text-[#a398d4] hover:text-white'}`}
                          >
                            {cat.icon}
                          </button>
                        ))}
                      </div>
                      <button onClick={() => setShowFaqPanel(false)} className="text-[#a398d4] hover:text-white text-xs px-1.5">✕</button>
                    </div>
                  </div>
                  <div className="max-h-48 overflow-y-auto p-2 grid grid-cols-1 gap-1">
                    {activeCategoryData.questions.map((q, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSendMessage(q)}
                        className="w-full text-left px-3 py-2 rounded-lg text-[11px] text-[#c4b5fd] hover:bg-[#2a2068] hover:text-white border border-transparent hover:border-[#4a3d92] transition-all flex items-center gap-2 group"
                      >
                        <span className="text-[9px] w-4 h-4 rounded-full flex items-center justify-center shrink-0 font-bold bg-[#241b5a] text-[#a398d4] group-hover:bg-violet-600 group-hover:text-white transition-colors">{idx + 1}</span>
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Input Box */}
            <div className="p-3 bg-[#120c33] border-t border-[#241b5a] flex justify-center">
              <div className="w-full max-w-2xl space-y-1.5">
                <form 
                  onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }}
                  className="flex items-center gap-2 bg-[#1b1542] border border-[#352b78] focus-within:border-violet-500 rounded-xl px-3 py-1.5 transition-colors"
                >
                  <button
                    type="button"
                    onClick={() => {
                      if (!showFaqPanel) setActiveFaqCategory('security');
                      setShowFaqPanel(prev => !prev);
                    }}
                    title="Browse preset scenarios & questions"
                    className={`p-1.5 rounded-lg transition-colors shrink-0 ${showFaqPanel ? 'bg-violet-600 text-white' : 'text-[#a398d4] hover:text-white hover:bg-[#352b78]'}`}
                  >
                    <HelpCircle className="w-3.5 h-3.5" />
                  </button>

                  <input
                    type="text"
                    value={inputQuery}
                    onChange={(e) => setInputQuery(e.target.value)}
                    placeholder={`Ask about fee status, policy, update records, or test guardrails as ${activeStudentId}...`}
                    className="flex-1 bg-transparent text-xs text-[#ede9fe] placeholder-[#a398d4] focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={!inputQuery.trim() || loading}
                    className="p-1.5 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 disabled:opacity-40 text-white transition-colors shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>

                <div className="flex items-center justify-between text-[10px] text-[#a398d4] px-1">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    Student Identity & Data Privacy Controls Active
                  </span>
                  <div className="flex gap-2">
                    <button onClick={() => handleSendMessage("What was the fact discussed earlier about my preference?")} className="hover:text-violet-400 transition-colors">
                      🧠 Recall Prior Fact
                    </button>
                    <span>•</span>
                    <button onClick={() => handleSendMessage("Does the campus have an underground helicopter landing pad for students?")} className="hover:text-violet-400 transition-colors">
                      ❓ Test Fallback
                    </button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* ----------------- TAB 2: AUDIT TRAIL LOG ----------------- */}
        {activeTab === 'audit' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-4 flex flex-col items-center">
            <div className="w-full max-w-5xl space-y-4">
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-rose-400" /> Institutional Audit Records (Compliance Trail)
                  </h3>
                  <p className="text-xs text-[#a398d4]">
                    Tamper-evident log recording who requested each action, what was attempted, whether it was allowed or approved, and the final result.
                  </p>
                </div>
                <button
                  onClick={fetchAuditLogs}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#241b5a] hover:bg-[#352b78] text-[#ddd6fe] font-medium text-xs transition-colors border border-[#352b78]"
                >
                  <RefreshCw className="w-3 h-3" /> Refresh Logs
                </button>
              </div>

              {/* Audit Summary KPI Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-[#1b1542] border border-[#352b78] p-3 rounded-lg">
                  <span className="text-[10px] text-[#a398d4] block font-medium">Total Audit Entries</span>
                  <span className="text-lg font-bold text-white mt-0.5 block">{auditLogs.length}</span>
                  <span className="text-[10px] text-violet-400">Recorded in audit_log.json</span>
                </div>
                <div className="bg-[#1b1542] border border-[#352b78] p-3 rounded-lg">
                  <span className="text-[10px] text-[#a398d4] block font-medium">Access Allowed</span>
                  <span className="text-lg font-bold text-emerald-400 mt-0.5 block">
                    {auditLogs.filter(l => l.authorization_status === 'ALLOWED').length}
                  </span>
                  <span className="text-[10px] text-emerald-400">Own records authorized</span>
                </div>
                <div className="bg-[#1b1542] border border-[#352b78] p-3 rounded-lg">
                  <span className="text-[10px] text-[#a398d4] block font-medium">Access Blocked</span>
                  <span className="text-lg font-bold text-rose-400 mt-0.5 block">
                    {auditLogs.filter(l => l.authorization_status === 'DENIED_UNAUTHORIZED').length}
                  </span>
                  <span className="text-[10px] text-rose-400">Cross-access / OTP blocked</span>
                </div>
                <div className="bg-[#1b1542] border border-[#352b78] p-3 rounded-lg">
                  <span className="text-[10px] text-[#a398d4] block font-medium">Approval Actions</span>
                  <span className="text-lg font-bold text-amber-400 mt-0.5 block">
                    {auditLogs.filter(l => ['APPROVAL_REQUIRED', 'APPROVED', 'REJECTED'].includes(l.authorization_status)).length}
                  </span>
                  <span className="text-[10px] text-amber-400">Human-in-the-loop</span>
                </div>
              </div>

              {/* Full Audit Log Table */}
              <div className="bg-[#1b1542] border border-[#352b78] rounded-lg overflow-hidden shadow-lg">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#120c33] text-[#a398d4] uppercase tracking-wider font-semibold border-b border-[#352b78] text-[10px]">
                      <tr>
                        <th className="p-2.5">Audit ID</th>
                        <th className="p-2.5">Timestamp</th>
                        <th className="p-2.5">Actor (Who)</th>
                        <th className="p-2.5">Action Attempted</th>
                        <th className="p-2.5">Target Resource</th>
                        <th className="p-2.5">Permission Decision</th>
                        <th className="p-2.5">Final Result</th>
                        <th className="p-2.5">Audit Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#352b78]/60 font-mono text-[10px]">
                      {auditLogs.slice().reverse().map((entry, idx) => (
                        <tr key={idx} className="hover:bg-[#352b78]/30 transition-colors">
                          <td className="p-2.5 font-bold text-white whitespace-nowrap">{entry.audit_id}</td>
                          <td className="p-2.5 text-[#a398d4] whitespace-nowrap">{entry.timestamp}</td>
                          <td className="p-2.5 font-bold text-violet-300">{entry.actor_student_id}</td>
                          <td className="p-2.5 text-[#ddd6fe] font-sans">{entry.action_type}</td>
                          <td className="p-2.5 text-[#c4b5fd]">{entry.target_resource}</td>
                          <td className="p-2.5">
                            <span className={`px-1.5 py-0.5 rounded font-bold text-[9px] ${
                              entry.authorization_status === 'ALLOWED' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                              (entry.authorization_status === 'DENIED_UNAUTHORIZED' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' :
                              'bg-amber-500/20 text-amber-300 border border-amber-500/40')
                            }`}>
                              {entry.authorization_status}
                            </span>
                          </td>
                          <td className="p-2.5">
                            <span className={`px-1.5 py-0.5 rounded font-bold text-[9px] ${
                              entry.execution_result === 'SUCCESS' || entry.execution_result === 'EXECUTED' ? 'bg-emerald-500/20 text-emerald-300' :
                              (entry.execution_result === 'BLOCKED' || entry.execution_result === 'ABORTED_NO_CHANGE' ? 'bg-rose-500/20 text-rose-300' :
                              'bg-amber-500/20 text-amber-300')
                            }`}>
                              {entry.execution_result}
                            </span>
                          </td>
                          <td className="p-2.5 font-sans text-[#c4b5fd] max-w-xs">{entry.details}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ----------------- TAB 3: HUMAN APPROVALS MANAGER ----------------- */}
        {activeTab === 'approvals' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-4 flex flex-col items-center">
            <div className="w-full max-w-4xl space-y-4">
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Lock className="w-5 h-5 text-amber-400" /> Human-in-the-Loop Approval Manager
                  </h3>
                  <p className="text-xs text-[#a398d4]">
                    Sensitive modifications to student records are halted until explicitly approved or rejected by an administrator or student.
                  </p>
                </div>
                <button
                  onClick={fetchApprovals}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#241b5a] hover:bg-[#352b78] text-[#ddd6fe] font-medium text-xs transition-colors border border-[#352b78]"
                >
                  <RefreshCw className="w-3 h-3" /> Refresh
                </button>
              </div>

              {/* Pending Approvals Section */}
              <div className="space-y-2">
                <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider block">
                  Pending Approvals Awaiting Review ({approvals.pending_approvals?.length || 0})
                </span>

                {approvals.pending_approvals?.length > 0 ? (
                  <div className="space-y-2.5">
                    {approvals.pending_approvals.map((req, idx) => (
                      <div key={idx} className="bg-[#1b1542] border border-amber-500/40 p-4 rounded-xl space-y-2.5 shadow-md">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-sm text-amber-300">{req.approval_id}</span>
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded font-mono font-bold animate-pulse">
                            PENDING_APPROVAL
                          </span>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs bg-[#0d0929] p-2.5 rounded-lg border border-[#241b5a]">
                          <div>
                            <span className="text-[10px] text-[#a398d4] block">Requesting Student:</span>
                            <span className="font-mono text-white font-semibold">{req.actor_student_id}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#a398d4] block">Target Student Record:</span>
                            <span className="font-mono text-white font-semibold">{req.target_student_id}</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-[#a398d4] block">Action Type:</span>
                            <span className="text-violet-300 font-semibold">{req.action_type}</span>
                          </div>
                        </div>

                        <div className="text-xs">
                          <span className="text-[#a398d4] block mb-0.5">Proposed Modification:</span>
                          <div className="bg-[#0d0929] p-2 rounded border border-[#241b5a] font-mono text-emerald-300 text-[11px]">
                            {JSON.stringify(req.requested_changes)}
                          </div>
                        </div>

                        <div className="flex gap-2 pt-1">
                          <button
                            onClick={() => handleResolveApproval(req.approval_id, 'APPROVED')}
                            disabled={resolvingApprovalId === req.approval_id}
                            className="flex-1 py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
                          >
                            <CheckCircle className="w-4 h-4" /> Approve & Execute Modification
                          </button>
                          <button
                            onClick={() => handleResolveApproval(req.approval_id, 'REJECTED')}
                            disabled={resolvingApprovalId === req.approval_id}
                            className="flex-1 py-2 px-3 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
                          >
                            <XCircle className="w-4 h-4" /> Reject & Abort (No DB Change)
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-[#1b1542] border border-[#352b78] p-4 rounded-xl text-center text-xs text-[#a398d4]">
                    No pending approval requests. Use chat to request a sensitive change (e.g., <code className="text-violet-400 font-mono">"Update my contact phone to +91-9876543210"</code>).
                  </div>
                )}
              </div>

              {/* Resolved Approvals History */}
              {approvals.all_approvals?.filter(a => a.status !== 'PENDING_APPROVAL').length > 0 && (
                <div className="space-y-2 pt-2">
                  <span className="text-xs font-semibold text-[#a398d4] uppercase tracking-wider block">
                    Historical Resolved Requests
                  </span>
                  <div className="bg-[#1b1542] border border-[#352b78] rounded-lg overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#120c33] text-[#a398d4] uppercase text-[10px] border-b border-[#352b78]">
                        <tr>
                          <th className="p-2.5">Approval ID</th>
                          <th className="p-2.5">Student</th>
                          <th className="p-2.5">Action</th>
                          <th className="p-2.5">Decision</th>
                          <th className="p-2.5">Execution Status</th>
                          <th className="p-2.5">Resolved By</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#352b78]/60 font-mono text-[10px]">
                        {approvals.all_approvals.filter(a => a.status !== 'PENDING_APPROVAL').map((a, idx) => (
                          <tr key={idx}>
                            <td className="p-2.5 font-bold text-white">{a.approval_id}</td>
                            <td className="p-2.5 text-violet-300">{a.target_student_id}</td>
                            <td className="p-2.5 text-[#c4b5fd] font-sans">{a.action_type}</td>
                            <td className="p-2.5">
                              <span className={`px-1.5 py-0.5 rounded font-bold ${a.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
                                {a.status}
                              </span>
                            </td>
                            <td className="p-2.5 text-[#a398d4] font-sans">{a.execution_status}</td>
                            <td className="p-2.5 text-[#c4b5fd] font-sans">{a.resolved_by}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

        {/* ----------------- TAB 4: FINAL EVALUATION TABLE ----------------- */}
        {activeTab === 'benchmark' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-4 flex flex-col items-center">
            <div className="w-full max-w-5xl space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">System Verification & Performance Benchmark</h3>
                  <p className="text-xs text-[#a398d4]">
                    Comparative measurements on Task Accuracy, Privacy Tests, Unsafe-Action Controls, Latency, and Token Footprint.
                  </p>
                </div>
                <button
                  onClick={handleRunBenchmark}
                  disabled={benchmarkLoading}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-medium text-xs transition-colors shadow-sm shrink-0"
                >
                  <RefreshCw className={`w-3 h-3 ${benchmarkLoading ? 'animate-spin' : ''}`} /> Run Comparative Benchmark
                </button>
              </div>

              {/* Benchmark Results */}
              {benchmarkResults ? (
                <div className="space-y-4">
                  
                  {/* Privacy & Safety Scenarios Result Table */}
                  <div className="bg-[#1b1542] border border-[#352b78] rounded-lg overflow-hidden shadow-lg">
                    <div className="p-3 bg-[#120c33] border-b border-[#352b78] flex items-center justify-between">
                      <span className="font-bold text-xs text-white flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-emerald-400" /> Privacy & Safety Verification Results
                      </span>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded font-mono font-bold">
                        5 / 5 Scenarios Passed (100%)
                      </span>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-[#120c33] text-[#a398d4] uppercase tracking-wider font-semibold border-b border-[#352b78] text-[10px]">
                          <tr>
                            <th className="p-2.5">Scenario</th>
                            <th className="p-2.5">Student Actor</th>
                            <th className="p-2.5">Permission Decision</th>
                            <th className="p-2.5">Execution Result</th>
                            <th className="p-2.5">Privacy Test</th>
                            <th className="p-2.5">Unsafe Action Test</th>
                            <th className="p-2.5">Latency</th>
                            <th className="p-2.5">Token In / Out</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#352b78]/60 font-mono text-[10px]">
                          {benchmarkResults.assignment2_results?.map((r, idx) => (
                            <tr key={idx} className="hover:bg-[#352b78]/30 transition-colors">
                              <td className="p-2.5 font-bold font-sans text-white">{r.name}</td>
                              <td className="p-2.5 text-violet-300">{r.actor}</td>
                              <td className="p-2.5">
                                <span className={`px-1.5 py-0.5 rounded font-bold ${r.permission_decision === 'ALLOWED' ? 'bg-emerald-500/20 text-emerald-300' : (r.permission_decision === 'APPROVAL_REQUIRED' ? 'bg-amber-500/20 text-amber-300' : 'bg-rose-500/20 text-rose-300')}`}>
                                  {r.permission_decision}
                                </span>
                              </td>
                              <td className="p-2.5 text-[#ddd6fe]">{r.status_result}</td>
                              <td className="p-2.5 text-emerald-400 font-bold font-sans">{r.privacy_test}</td>
                              <td className="p-2.5 text-purple-400 font-bold font-sans">{r.unsafe_action_test}</td>
                              <td className="p-2.5 text-[#c4b5fd]">{r.latency_s}s</td>
                              <td className="p-2.5 text-[#a398d4]">{r.token_usage?.prompt_tokens} / {r.token_usage?.completion_tokens}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Markdown Report Render */}
                  <div className="bg-[#1b1542] border border-[#352b78] rounded-lg p-4 text-xs text-[#ddd6fe] markdown-body">
                    <ReactMarkdown>{benchmarkResults.markdown_report}</ReactMarkdown>
                  </div>
                </div>
              ) : (
                <div className="bg-[#1b1542] border border-[#352b78] p-8 rounded-xl text-center space-y-2">
                  <BarChart3 className="w-8 h-8 text-violet-400 mx-auto" />
                  <p className="text-sm font-semibold text-white">Comparative Benchmark Not Run Yet</p>
                  <p className="text-xs text-[#a398d4]">Click the button above to execute the live measurement suite and generate the comparative evaluation report.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ----------------- TAB 5: POLICY HANDBOOK (RAG) ----------------- */}
        {activeTab === 'policy' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-4 flex flex-col items-center">
            <div className="w-full max-w-4xl space-y-4">
              <div>
                <h3 className="text-base font-bold text-white">Institutional Policy Manual & Selective Context RAG</h3>
                <p className="text-xs text-[#a398d4]">Verifies that the agent selectively extracts specific section chunks rather than sending the entire manual.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {policyChunks.map((chunk, idx) => (
                  <div key={idx} className="bg-[#1b1542] border border-[#352b78]/80 p-3 rounded-lg space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-violet-400">{chunk.title}</span>
                      <span className="text-[9px] bg-[#241b5a] px-1.5 py-0.5 rounded font-mono text-[#c4b5fd]">{chunk.chunk_id}</span>
                    </div>
                    <p className="text-[11px] text-[#c4b5fd] leading-relaxed">{chunk.content}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ----------------- TAB 6: STUDENT REGISTRY ----------------- */}
        {activeTab === 'database' && (
          <div className="flex-1 overflow-y-auto p-5 space-y-4 flex flex-col items-center">
            <div className="w-full max-w-4xl space-y-4">
              <div>
                <h3 className="text-base font-bold text-white">Institutional Student Registry & Live State</h3>
                <p className="text-xs text-[#a398d4]">Demonstrates live student records, phone numbers, balance dues, and scholarship schemes.</p>
              </div>

              <div className="bg-[#1b1542] border border-[#352b78]/80 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#120c33] text-[#a398d4] uppercase tracking-wider font-semibold border-b border-[#352b78] text-[10px]">
                    <tr>
                      <th className="p-2.5">Student ID</th>
                      <th className="p-2.5">Name</th>
                      <th className="p-2.5">Programme</th>
                      <th className="p-2.5">CGPA</th>
                      <th className="p-2.5">Attendance</th>
                      <th className="p-2.5">Phone</th>
                      <th className="p-2.5">Fee Due</th>
                      <th className="p-2.5">Scholarship</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#352b78]/60 text-[#ddd6fe] text-xs">
                    {students.map(s => (
                      <tr key={s.student_id}>
                        <td className="p-2.5 font-mono font-bold text-white">{s.student_id}</td>
                        <td className="p-2.5 font-semibold">{s.name}</td>
                        <td className="p-2.5 text-[#a398d4]">{s.programme}</td>
                        <td className="p-2.5 text-violet-400 font-bold">{s.cgpa}</td>
                        <td className="p-2.5 text-purple-400 font-bold">{s.attendance_percentage}%</td>
                        <td className="p-2.5 font-mono text-[#c4b5fd]">{s.phone || "+91-9811002233"}</td>
                        <td className="p-2.5">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${s.fee_details?.outstanding_due > 0 ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                            INR {s.fee_details?.outstanding_due?.toLocaleString()}
                          </span>
                        </td>
                        <td className="p-2.5 text-[#c4b5fd]">{s.scholarship?.scheme_name || "None"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
